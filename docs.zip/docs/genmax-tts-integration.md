# GenMax TTS Integration — NestJS

Hướng dẫn tích hợp Text-to-Speech qua [GenMax API](https://genmax.io) vào NestJS project.
GenMax là proxy hỗ trợ nhiều provider TTS (ElevenLabs, MiniMax). Guide này dùng **MiniMax** provider.

---

## 1. Chuẩn bị

### 1.1 Tài khoản GenMax
1. Đăng ký tại [genmax.io](https://genmax.io)
2. Vào **Dashboard → API Keys** → tạo API key, copy giá trị `sk_...`
3. Nạp credits (TTS tốn credits theo số ký tự)

### 1.2 Lấy Voice ID (MiniMax)
1. Vào GenMax → **Voice Library** → chọn giọng MiniMax muốn dùng
2. Copy **Voice ID** (dạng UUID: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`)

---

## 2. Cấu hình Environment

Thêm vào file `.env`:

```env
GENMAX_API_KEY="sk_your_api_key_here"
MINIMAX_VOICE_ID="your-voice-uuid-here"
```

---

## 3. Tạo TTS Module

### 3.1 File `src/tts/tts.module.ts`

```typescript
import { Module } from '@nestjs/common';
import { TtsService } from './tts.service';

@Module({
  providers: [TtsService],
  exports: [TtsService],
})
export class TtsModule {}
```

### 3.2 File `src/tts/tts.service.ts`

```typescript
import { Injectable } from '@nestjs/common';
import * as https from 'https';

const CHUNK_SIZE = 2500;       // ký tự tối đa mỗi request
const POLL_INTERVAL_MS = 3000; // poll mỗi 3 giây
const POLL_MAX_ATTEMPTS = 40;  // timeout sau ~2 phút

@Injectable()
export class TtsService {
  private apiKey: string;
  private voiceId: string;

  constructor() {
    this.apiKey = process.env.GENMAX_API_KEY ?? '';
    this.voiceId = process.env.MINIMAX_VOICE_ID ?? '';
  }

  async synthesize(text: string): Promise<Buffer> {
    if (!this.apiKey || !this.voiceId) {
      throw new Error('GENMAX_API_KEY or MINIMAX_VOICE_ID not set');
    }
    const chunks = this.chunkText(text);
    const buffers: Buffer[] = [];
    for (const chunk of chunks) {
      buffers.push(await this.callApi(chunk));
    }
    return Buffer.concat(buffers);
  }

  private async callApi(text: string): Promise<Buffer> {
    const body = JSON.stringify({
      text,
      model_id: 'speech-2.8-turbo',
      provider: 'minimax',
      language_code: 'Vietnamese',
      voice_settings: { speed: 1.0, pitch: 0, vol: 1.0 },
    });

    const { statusCode, contentType, buf } = await this.httpRequest({
      hostname: 'api.genmax.io',
      path: `/v1/text-to-speech/${this.voiceId}`,
      method: 'POST',
      headers: {
        'xi-api-key': this.apiKey,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
        Accept: 'audio/mpeg',
      },
      body,
    });

    if (statusCode && statusCode >= 400) {
      throw new Error(`GenMax TTS error ${statusCode}: ${buf.toString()}`);
    }

    if (contentType.includes('audio')) {
      return buf;
    }

    // GenMax trả về async job
    let json: { id?: string; status?: string };
    try {
      json = JSON.parse(buf.toString());
    } catch {
      throw new Error(`GenMax TTS unexpected response: ${buf.toString()}`);
    }

    if (!json.id) {
      throw new Error(`GenMax TTS unexpected response: ${buf.toString()}`);
    }

    console.log(`TTS job queued: ${json.id}, polling...`);
    return this.pollJob(json.id);
  }

  private async pollJob(jobId: string): Promise<Buffer> {
    for (let attempt = 1; attempt <= POLL_MAX_ATTEMPTS; attempt++) {
      await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));

      const { statusCode, buf } = await this.httpRequest({
        hostname: 'api.genmax.io',
        path: `/v1/history/${jobId}`,
        method: 'GET',
        headers: { 'xi-api-key': this.apiKey, Accept: 'application/json' },
      });

      if (statusCode && statusCode >= 400) {
        throw new Error(`GenMax poll error ${statusCode}: ${buf.toString()}`);
      }

      let json: { status?: string; progress?: number; result?: { audio_url?: string } } = {};
      try { json = JSON.parse(buf.toString()); } catch { /* keep polling */ }

      console.log(`TTS job ${jobId} status: ${json.status} progress: ${json.progress ?? 0} (attempt ${attempt})`);

      if (json.status === 'completed' || json.status === 'done') {
        const audioUrl = json.result?.audio_url;
        if (audioUrl) return this.downloadUrl(audioUrl);
        throw new Error(`GenMax job completed but no audio_url in response`);
      }

      if (json.status === 'failed' || json.status === 'error') {
        throw new Error(`GenMax TTS job failed: ${buf.toString()}`);
      }
    }
    throw new Error(`GenMax TTS job ${jobId} timed out after ${POLL_MAX_ATTEMPTS} attempts`);
  }

  private downloadUrl(url: string): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      https.get(url, (res) => {
        const parts: Buffer[] = [];
        res.on('data', (d) => parts.push(d));
        res.on('end', () => resolve(Buffer.concat(parts)));
      }).on('error', reject);
    });
  }

  private httpRequest(opts: {
    hostname: string;
    path: string;
    method: string;
    headers: Record<string, string | number>;
    body?: string;
  }): Promise<{ statusCode: number | undefined; contentType: string; buf: Buffer }> {
    return new Promise((resolve, reject) => {
      const req = https.request(opts, (res) => {
        const parts: Buffer[] = [];
        res.on('data', (d) => parts.push(d));
        res.on('end', () =>
          resolve({
            statusCode: res.statusCode,
            contentType: (res.headers['content-type'] as string) ?? '',
            buf: Buffer.concat(parts),
          }),
        );
      });
      req.on('error', reject);
      if (opts.body) req.write(opts.body);
      req.end();
    });
  }

  private chunkText(text: string): string[] {
    if (text.length <= CHUNK_SIZE) return [text];
    const chunks: string[] = [];
    let remaining = text;
    while (remaining.length > CHUNK_SIZE) {
      let cutAt = CHUNK_SIZE;
      const best = Math.max(
        remaining.lastIndexOf('\n', CHUNK_SIZE),
        remaining.lastIndexOf('.', CHUNK_SIZE),
      );
      if (best > CHUNK_SIZE * 0.6) cutAt = best + 1;
      chunks.push(remaining.slice(0, cutAt).trim());
      remaining = remaining.slice(cutAt).trim();
    }
    if (remaining.length > 0) chunks.push(remaining);
    return chunks;
  }
}
```

---

## 4. Đăng ký vào Feature Module

Import `TtsModule` vào module nào cần dùng:

```typescript
// src/your-feature/your-feature.module.ts
import { TtsModule } from '../tts/tts.module';

@Module({
  imports: [TtsModule],
  ...
})
export class YourFeatureModule {}
```

Inject `TtsService` vào service:

```typescript
// src/your-feature/your-feature.service.ts
import { TtsService } from '../tts/tts.service';
import * as fs from 'fs';

constructor(private ttsService: TtsService) {}

async generateAudio(text: string, outputPath: string) {
  const buffer = await this.ttsService.synthesize(text);
  fs.writeFileSync(outputPath, buffer);
}
```

---

## 5. Luồng hoạt động

```
synthesize(text)
  │
  ├─ chunkText()          // cắt text thành chunks ≤ 2500 ký tự
  │
  └─ callApi(chunk) × N   // với mỗi chunk:
       │
       ├─ POST /v1/text-to-speech/{voiceId}
       │    └─ response: { id: "...", status: "pending" }
       │
       └─ pollJob(id)      // poll mỗi 3s tối đa 40 lần
            │
            ├─ GET /v1/history/{id}
            │    └─ response: { status: "processing", progress: 0-100 }
            │
            └─ khi status = "completed"
                 └─ GET result.audio_url → download MP3 buffer

→ concat tất cả buffers → trả về Buffer MP3
```

---

## 6. Provider khác: ElevenLabs

Nếu muốn dùng ElevenLabs thay MiniMax, đổi trong `callApi`:

```typescript
// .env
ELEVENLABS_VOICE_ID="your-elevenlabs-voice-id"

// tts.service.ts — trong callApi():
const body = JSON.stringify({
  text,
  model_id: 'eleven_turbo_v2_5',  // hoặc 'eleven_multilingual_v2'
  provider: 'elevenlabs',
  language_code: 'vi',
  voice_settings: { stability: 0.5, similarity_boost: 0.75, speed: 1.0 },
});
```

> **Lưu ý:** `eleven_multilingual_v2` không nhận `language_code` — dùng `eleven_turbo_v2_5` nếu cần chỉ định ngôn ngữ.

---

## 7. Các lỗi thường gặp

| Lỗi | Nguyên nhân | Cách fix |
|-----|-------------|----------|
| `400 language_code is required` | Thiếu field `language_code` | Thêm `language_code` vào body |
| `400 language_code 'vi' is not supported` | Model không hỗ trợ code ngắn | Dùng `'Vietnamese'` hoặc đổi model |
| `402 insufficient credits` | Hết credits GenMax | Nạp thêm tại GenMax dashboard |
| `job timed out` | GenMax quá tải hoặc text quá dài | Tăng `POLL_MAX_ATTEMPTS` hoặc giảm `CHUNK_SIZE` |
